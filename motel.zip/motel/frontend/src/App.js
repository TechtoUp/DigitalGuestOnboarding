// src/App.js
import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import AdminPanel from './components/AdminPanel';
import GuestForm from './components/GuestForm';
import Login from './components/Login';
import HotelList from './components/HotelList';
import HotelLandingPage from './components/HotelLandingPage';
import ThankYouPage from './components/ThankYouPage';
import Header from './components/Header';
import Footer from './components/Footer';
import LandingPage from './components/LandingPage';
import Registration from './components/Registration';
import './styles/app.css';

const App = () => {
  const location = useLocation();

  // Define pages where Header and Footer should not appear
  const hideHeaderFooter = ['/login', '/register'];

  return (
    <div className="App">
      {/* Conditionally render Header */}
      {!hideHeaderFooter.includes(location.pathname) && <Header />}

      {/* Main Content */}
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registration />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="/hotels" element={<HotelList />} />
        <Route path="/:hotelName/guest-registration" element={<GuestForm />} />
        <Route path="/hotel/:hotelName" element={<HotelLandingPage />} />
        <Route path="/thank-you" element={<ThankYouPage />} />
      </Routes>

      {/* Conditionally render Footer */}
      {!hideHeaderFooter.includes(location.pathname) && <Footer />}
    </div>
  );
};

export default App;

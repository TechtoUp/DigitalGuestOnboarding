// src/components/GuestForm.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const GuestForm = () => {
  const { hotelName } = useParams(); // Get the hotel name from the URL
  const [formData, setFormData] = useState({
    fullName: '',
    mobileNumber: '',
    address: '',
    visitPurpose: '',
    stayDates: { from: '', to: '' },
    email: '',
    aadhaarNumber: '', // Updated ID proof to Aadhaar number
    hotel: '', // Hotel field
  });
  const [hotels, setHotels] = useState([]); // To store the list of hotels
  const navigate = useNavigate();

  // Fetch list of hotels from backend
  useEffect(() => {
    const fetchHotels = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/hotel'); // Your hotel fetching endpoint
        setHotels(response.data); // Store the hotels in state
      } catch (error) {
        console.error('Error fetching hotels:', error);
      }
    };
    fetchHotels();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('stayDates')) {
      const [field] = name.split('.');
      setFormData((prevState) => ({
        ...prevState,
        stayDates: { ...prevState.stayDates, [field]: value },
      }));
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const { from, to } = formData.stayDates;
    const sanitizedFormData = { ...formData, hotel: formData.hotel, stayDates: { from, to } };

    try {
      await axios.post('http://localhost:5000/api/guest/add', sanitizedFormData); // Send data to backend
      navigate('/thank-you'); // Redirect to Thank You page
    } catch (error) {
      console.error('Error registering guest:', error);
    }
  };

  return (
    <div className="container">
      <h1>{hotelName} - Guest Registration</h1>
      <form onSubmit={handleFormSubmit}>
        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={formData.fullName}
          onChange={handleInputChange}
          className="form-control"
        />
        <input
          type="number"
          name="mobileNumber"
          placeholder="Mobile Number"
          value={formData.mobileNumber}
          onChange={handleInputChange}
          className="form-control"
          min="0"
        />
        <input
          type="text"
          name="address"
          placeholder="Address"
          value={formData.address}
          onChange={handleInputChange}
          className="form-control"
        />
        <select
          name="visitPurpose"
          value={formData.visitPurpose}
          onChange={handleInputChange}
          className="form-control"
        >
          <option value="">Purpose of Visit</option>
          <option value="Business">Business</option>
          <option value="Personal">Personal</option>
          <option value="Tourist">Tourist</option>
        </select>

        <input
          type="date"
          name="stayDates.from"
          value={formData.stayDates.from}
          onChange={handleInputChange}
          className="form-control"
        />
        <input
          type="date"
          name="stayDates.to"
          value={formData.stayDates.to}
          onChange={handleInputChange}
          className="form-control"
        />

        <input
          type="email"
          name="email"
          placeholder="Email ID"
          value={formData.email}
          onChange={handleInputChange}
          className="form-control"
        />

        <input
          type="number"
          name="aadhaarNumber"
          placeholder="Aadhaar Number"
          value={formData.aadhaarNumber}
          onChange={handleInputChange}
          className="form-control"
          min="0"
        />

        {/* Hotel dropdown */}
        <select
          name="hotel"
          value={formData.hotel}
          onChange={handleInputChange}
          className="form-control"
        >
          <option value="">Select Hotel</option>
          {hotels.map((hotel) => (
            <option key={hotel._id} value={hotel._id}>
              {hotel.name} - {hotel.address}
            </option>
          ))}
        </select>

        <button type="submit" className="btn btn-primary">Register</button>
      </form>
    </div>
  );
};

export default GuestForm;

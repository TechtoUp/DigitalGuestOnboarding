import React from 'react';

const Header = () => {
  return (
    <header>
      <div className="container">
        <img src="https://imgs.search.brave.com/yH-fFBnKEtgf0n0UEommwI56ZgqEhmWFJgbS_o7vKTY/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9jZG4u/cGl4YWJheS5jb20v/cGhvdG8vMjAxOS8w/OS8wNy8wNC8xNC9u/ZW9uLTQ0NTc5MDBf/NjQwLmpwZw" alt="Motel" className="main-image" />
      </div>
    </header>
  );
};

export default Header;

import React from 'react';

const ThankYouPage = () => {
  return (
    <div className="container">
      <h1>Thank You!</h1>
      <p>Your registration has been successfully submitted. We look forward to welcoming you!</p>
    </div>
  );
};

export default ThankYouPage;

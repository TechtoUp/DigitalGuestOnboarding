import React from 'react';
import { useParams } from 'react-router-dom';

const HotelLandingPage = () => {
  const { hotelName } = useParams();

  return (
    <div className="container">
      <h1>Welcome to {hotelName}</h1>
      <p>Fill out the guest form below to register.</p>
      <a href={`/guest/${hotelName}`} className="btn btn-primary">Go to Registration Form</a>
    </div>
  );
};

export default HotelLandingPage;

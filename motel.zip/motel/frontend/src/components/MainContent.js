import React from 'react';

const MainContent = () => {
  return (
    <main>
      <div className="container">
        <h2>Hotel Registration</h2>
        {/* Main body content goes here */}
        <p>Here, you can add the forms and tables for the hotel management or guest registration</p>
      </div>
    </main>
  );
};

export default MainContent;

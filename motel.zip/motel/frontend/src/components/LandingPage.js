// src/components/LandingPage.js

import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/app.css'; // Import the CSS file

const LandingPage = () => {
  return (
    <div className="landing-page">
      <header className="header">
        <h1>Welcome to Our Motel</h1>
        <p>Experience the best stay with us.</p>
      </header>
      <img src="/images/book.png" alt="Motel" className="main-image" />
      <div className="buttons">
        <Link to="/register" className="btn btn-primary">Register</Link>
        <Link to="/login" className="btn btn-secondary">Login</Link>
      </div>
    </div>
  );
};

export default LandingPage;
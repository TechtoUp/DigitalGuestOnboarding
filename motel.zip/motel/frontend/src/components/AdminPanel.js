// src/components/AdminPanel.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../styles/app.css';

const AdminPanel = () => {
  const [hotels, setHotels] = useState([]);
  const [newHotel, setNewHotel] = useState({ name: '', address: '', logos: [] });
  const [confirmation, setConfirmation] = useState({ show: false, hotelId: '', hotelName: '' });
  const navigate = useNavigate();

  useEffect(() => {
    fetchHotels();
  }, []);

  const fetchHotels = async () => {
    try {
      const { data } = await axios.get('http://localhost:5000/api/hotel');
      setHotels(data);
    } catch (error) {
      console.error('Error fetching hotels:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'logos') {
      setNewHotel({ ...newHotel, logos: [...files] });
    } else {
      setNewHotel({ ...newHotel, [name]: value });
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', newHotel.name);
    formData.append('address', newHotel.address);

    newHotel.logos.forEach((logo) => {
      formData.append('logos', logo);
    });

    try {
      const { data } = await axios.post('http://localhost:5000/api/hotel/add', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setHotels([...hotels, data]);
      setNewHotel({ name: '', address: '', logos: [] });
    } catch (error) {
      console.error('Error adding hotel:', error.response ? error.response.data : error);
      alert('Failed to add hotel. Please check the input fields and try again.');
    }
  };

  const handleDelete = (id, name) => {
    setConfirmation({ show: true, hotelId: id, hotelName: name });
  };

  const confirmDelete = async () => {
    if (confirmation.hotelName.trim().toLowerCase() === confirmation.hotelName.toLowerCase()) {
      try {
        await axios.delete(`http://localhost:5000/api/hotel/${confirmation.hotelId}`, {
          data: { name: confirmation.hotelName },
        });
        setHotels(hotels.filter((hotel) => hotel._id !== confirmation.hotelId));
        setConfirmation({ show: false, hotelId: '', hotelName: '' });
      } catch (error) {
        console.error('Error deleting hotel:', error);
      }
    } else {
      alert('Hotel name does not match. Cannot delete.');
    }
  };

  const cancelDelete = () => {
    setConfirmation({ show: false, hotelId: '', hotelName: '' });
  };

  // Navigate to the "Register Guest" page
  const handleRegisterGuest = (hotelName) => {
    navigate(`/guest/${hotelName}`);
  };

  return (
    <div className="container">
      <h1>Admin Panel</h1>

      <form onSubmit={handleFormSubmit} className="hotel-form">
        <div className="form-control">
          <input
            type="text"
            name="name"
            placeholder="Hotel Name"
            value={newHotel.name}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-control">
          <input
            type="text"
            name="address"
            placeholder="Hotel Address"
            value={newHotel.address}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-control">
          <input
            type="file"
            name="logos"
            multiple
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-buttons">
          <button type="submit" className="submit-btn">Submit Hotel</button>
        </div>
      </form>

      <h2>Hotels</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Address</th>
            <th>Logos</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {hotels.map((hotel) => (
            <tr key={hotel._id}>
              <td>{hotel.name}</td>
              <td>{hotel.address}</td>
              <td>
                {hotel.logos && hotel.logos.map((logo, index) => (
                  <a href={logo} target="_blank" rel="noopener noreferrer" key={index}>
                    <img src={logo} alt={`Logo ${index + 1}`} width="50" />
                  </a>
                ))}
              </td>
              <td className="action-buttons">
                <button onClick={() => navigate(`/hotel/edit/${hotel._id}`)}>Edit</button>
                <button onClick={() => handleDelete(hotel._id, hotel.name)} className="remove-btn">Remove</button>
                <button onClick={() => handleRegisterGuest(hotel.name)} className="register-guest-btn">Register Guest</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {confirmation.show && (
        <div className="confirmation-popup">
          <h3>Are you sure you want to delete the hotel?</h3>
          <p>Type the hotel name to confirm:</p>
          <input
            type="text"
            value={confirmation.hotelName}
            onChange={(e) => setConfirmation({ ...confirmation, hotelName: e.target.value })}
            placeholder="Hotel Name"
          />
          <button onClick={confirmDelete}>Confirm</button>
          <button onClick={cancelDelete}>Cancel</button>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;

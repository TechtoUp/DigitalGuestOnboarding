import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const GuestForm = () => {
  const { hotelName } = useParams();
  const [formData, setFormData] = useState({
    fullName: '',
    mobileNumber: '',
    address: '',
    visitPurpose: '',
    stayDates: { from: '', to: '' },
    email: '',
    idProof: '',
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    axios.post(`/api/guest/register`, { ...formData, hotel: hotelName })
      .then(() => {
        // Redirect to thank you page or show success message
      })
      .catch(error => console.log(error));
  };

  return (
    <div className="container">
      <h1>{hotelName} - Guest Registration</h1>
      <form onSubmit={handleFormSubmit}>
        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={formData.fullName}
          onChange={handleInputChange}
          className="form-control"
        />
        <input
          type="text"
          name="mobileNumber"
          placeholder="Mobile Number"
          value={formData.mobileNumber}
          onChange={handleInputChange}
          className="form-control"
        />
        <input
          type="text"
          name="address"
          placeholder="Address"
          value={formData.address}
          onChange={handleInputChange}
          className="form-control"
        />
        <select
          name="visitPurpose"
          value={formData.visitPurpose}
          onChange={handleInputChange}
          className="form-control"
        >
          <option value="">Purpose of Visit</option>
          <option value="Business">Business</option>
          <option value="Personal">Personal</option>
          <option value="Tourist">Tourist</option>
        </select>
        <input
          type="date"
          name="stayDates.from"
          value={formData.stayDates.from}
          onChange={handleInputChange}
          className="form-control"
        />
        <input
          type="date"
          name="stayDates.to"
          value={formData.stayDates.to}
          onChange={handleInputChange}
          className="form-control"
        />
        <input
          type="email"
          name="email"
          placeholder="Email ID"
          value={formData.email}
          onChange={handleInputChange}
          className="form-control"
        />
        <input
          type="text"
          name="idProof"
          placeholder="ID Proof Number"
          value={formData.idProof}
          onChange={handleInputChange}
          className="form-control"
        />
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
};

export default GuestForm;

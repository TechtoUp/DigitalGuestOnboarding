import React from 'react';
import { Routes, Route } from 'react-router-dom';
import AdminPanel from './components/AdminPanel';
import GuestPanel from './components/GuestPanel';
import GuestForm from './components/GuestForm';
import HotelLandingPage from './components/HotelLandingPage';
import HotelList from './components/HotelList';
import Login from './components/Login';
import ThankYouPage from './components/ThankYouPage';

const AppRoutes = () => {
    return (
        <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/guest-admin" element={<GuestPanel />} />
            <Route path="/guest-form" element={<GuestForm />} />
            <Route path="/hotel/:id" element={<HotelLandingPage />} />
            <Route path="/hotels" element={<HotelList />} />
            <Route path="/thank-you" element={<ThankYouPage />} />
        </Routes>
    );
};

export default AppRoutes;
